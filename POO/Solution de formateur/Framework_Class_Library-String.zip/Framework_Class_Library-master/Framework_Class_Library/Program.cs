﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Framework_Class_Library
{
    class Program
    {
        static void Main(string[] args)
        {
            // new Exemple_Int();


            new Exemple_String();
            Console.Read();

        }
    }
}
